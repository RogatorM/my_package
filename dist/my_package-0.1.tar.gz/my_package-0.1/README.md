#my_package
This library was created to store recursion and sorting functions

#building this package locally
python setup.py sdist

#installing this package from GitHub
pip install git+https://github.com/RogatorM/example-python-package.git

#updating this package from GitHub
pip install --upgrade git+https://github.com/RogatorM/example-python-package.git
